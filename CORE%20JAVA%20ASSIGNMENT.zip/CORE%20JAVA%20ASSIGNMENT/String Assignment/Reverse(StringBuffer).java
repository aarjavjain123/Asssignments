import java.util.*;
public class Reverse {
	public static void main(String[] args)
	{
		StringBuffer br=new StringBuffer("This method returns the reversed object on which it was called");
		br.reverse();
		System.out.println(br);
	}

}

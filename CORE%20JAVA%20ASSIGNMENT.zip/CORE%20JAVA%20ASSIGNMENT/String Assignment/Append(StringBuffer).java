import java.util.*;
public class Ammend {
	public static void main(String[] args)
	{
		StringBuffer br=new StringBuffer("String");
		br.append(" is a peer class of string that provides much of functionality of strings.");
		System.out.println(br);
	}

}

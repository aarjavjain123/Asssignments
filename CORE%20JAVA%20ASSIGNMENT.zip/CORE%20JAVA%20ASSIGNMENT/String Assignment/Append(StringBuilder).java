import java.util.*;
public class Append {
	public static void main(String[] args)
	{
		StringBuilder bl=new StringBuilder("String");
		bl.append(" is a peer class of string that provides much of functionality of strings.");
		System.out.println(bl);
	}

}

import java.util.*;
public class concat {
	public static void main(String[] args)
	{
		String x="Hello, ";
		String y="How are you?";
		String z=x.concat(y);
		System.out.println(z);
	}
	
	

}

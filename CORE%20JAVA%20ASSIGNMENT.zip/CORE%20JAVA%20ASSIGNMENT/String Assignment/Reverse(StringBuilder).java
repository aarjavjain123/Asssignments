import java.util.*;
public class Reverse {
	public static void main(String[] args)
	{
		StringBuilder bl=new StringBuilder("This method returns the reversed object on which it was called");
		bl.reverse();
		System.out.println(bl);
	}

}

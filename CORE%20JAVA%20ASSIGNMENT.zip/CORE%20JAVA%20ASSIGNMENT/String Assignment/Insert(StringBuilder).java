import java.util.*;
public class Insert {
	public static void main(String[] args)
	{
		StringBuilder bl=new StringBuilder("It is used to ");
		bl.insert(14, "insert text");
		System.out.println(bl);
	}

}

import java.util.*;
public class Length {
	public static void main(String[] args)
	{
		int l;
		String s="Hello World";
		l=s.length();
		System.out.println("The length of the String "+s+" is " +l);
		
	}
}

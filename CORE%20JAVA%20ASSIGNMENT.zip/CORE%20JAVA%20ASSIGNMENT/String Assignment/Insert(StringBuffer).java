import java.util.*;
public class Insert {
	public static void main(String[] args)
	{
		StringBuffer br=new StringBuffer("it is used to ");
		br.insert(14, "insert text");
		System.out.println(br);
	}

}
